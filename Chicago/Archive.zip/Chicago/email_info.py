EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'chicagocloud2018@gmail.com'
EMAIL_HOST_PASSWORD = 'An6248322'
EMAIL_PORT = 587